# Schlüsseldienst Vogel – Onepager (Hugo) mit Decap CMS (GitHub Backend)

Dieser Build bietet einen **kostenlosen, "Elementor-ähnlichen" Block‑Editor** über Decap CMS:
- **Startseite als Blöcke** (Hero, Leistungen, Preise, Kontakt) – frei **hinzufügen/umordnen**.
- **/admin** lauffähig mit **GitHub Backend** (host‑unabhängig, z. B. Cloudflare Pages, Vercel, GitHub Pages).

## Deploy (z. B. Cloudflare Pages)
1. Repo zu GitHub pushen.
2. Cloudflare → Pages → Project erstellen → Connect to Git.
3. **Preset:** Hugo · **Build:** `hugo -b $CF_PAGES_URL --minify` · **Output:** `public`.
4. Nach dem ersten Deploy ist die Seite unter `<project>.pages.dev` erreichbar.

## Decap CMS (GitHub Backend) einrichten
> Ziel: Login mit GitHub, CMS schreibt Commit direkt in dein Repo. Kostenlos, aber **erfordert ein OAuth‑Backend**.

### Variante A: Eigenes OAuth‑Backend deployen (empfohlen)
1. **GitHub OAuth App** anlegen: *Settings → Developer settings → OAuth Apps → New OAuth App*  
   - Homepage: deine Seite (z. B. `https://schluesseldienst-vogel.pages.dev`)  
   - **Authorization callback URL:** `https://<dein-oauth-backend>/callback`
2. Ein **Decap OAuth Proxy** deployen (kostenlos) – z. B. Projekt `decap-cms-github-backend` auf Vercel/Workers.  
3. In `/static/admin/config.yml` eintragen:  
   ```yaml
   backend:
     name: github
     repo: your-github-user/your-repo
     branch: main
     base_url: https://<dein-oauth-backend>
     auth_endpoint: /auth
   ```
4. `/admin` öffnen → GitHub Login → editieren.

### Variante B: Netlify Identity + Git Gateway (einfacher, aber Netlify‑gebunden)
- Site (auch Blank) auf Netlify anlegen → **Identity aktivieren** → **Git Gateway** einschalten.  
- In `/static/admin/config.yml` stattdessen:  
  ```yaml
  backend:
    name: git-gateway
    branch: main
  ```
- Vorteil: kein eigenes OAuth nötig, Nachteil: an Netlify gebunden.

## Builder (Blöcke) bedienen
- `/admin` → **Startseite (Onepager)** → **Abschnitte** (Liste):  
  - **Hero**: Überschrift, Unterzeile, Highlights, Buttontext  
  - **Leistungen**: beliebig viele Karten  
  - **Preise**: beliebig viele Boxen (Zeilen)  
  - **Kontakt**: Überschrift & Hinweistext  
- Abschnitte **ziehen/umordnen**, hinzufügen, entfernen → **Save** → neue Version wird gebaut.

## Stammdaten setzen
- In `hugo.toml` unter `[params]` **phone, email, addressStreet, addressPostal, addressCity, serviceArea, openingHours** pflegen (LocalBusiness‑Schema nutzt diese Angaben).

## Kontaktformular
- Standardmäßig auf **Formspree** vorbereitet. Ersetze `your_form_id` in `layouts/blocks/kontakt.html` nach dem Anlegen einer kostenlosen Form bei Formspree.

## Eigene Domain
- Cloudflare Pages → **Custom domains** → CNAME für `www` auf `<project>.pages.dev`.  
- Optional Apex auf Cloudflare umziehen (Nameserverwechsel), dann Apex direkt verbinden.

Viel Erfolg!