---
title: "Start"
blocks:
  - kind: hero
    headline: "Schlüsseldienst Vogel – 24/7 Türöffnung & Einbruchschutz"
    subline: "Schnell vor Ort in Ihrer Stadt & Umgebung – faire Festpreise."
    bullets:
      - { text: "Tür zugefallen" }
      - { text: "Schloss defekt" }
      - { text: "Zylinderwechsel" }
      - { text: "Einbruchschutz" }
    ctaText: "Jetzt anrufen"
  - kind: leistungen
    title: "Unsere Leistungen"
    items:
      - { title: "Türöffnung", text: "95% beschädigungsfrei. Ausweis bitte bereithalten." }
      - { title: "Zylinder-/Schlossaustausch", text: "Fachgerechter Tausch – auf Wunsch mit Sicherungskarte." }
      - { title: "Einbruchschutz", text: "Beratung & Nachrüstung von Schutzbeschlägen und Riegeln." }
  - kind: preise
    title: "Transparente Preise"
    boxes:
      - { title: "Tür zugefallen (8–18 Uhr)", row1: "ab 69 €", row2: "inkl. Anfahrt in Ihrer Stadt" }
      - { title: "Notdienst (abends/WE)", row1: "+ 20–50 € Zuschlag", row2: "Kartenzahlung möglich" }
      - { title: "Beratung vor Ort", row1: "Kostenlose Erstberatung", row2: "Individuelles Angebot" }
  - kind: kontakt
    title: "Kontakt & Notdienst"
    note: "Rufen Sie uns an – wir sind rund um die Uhr erreichbar."
---
