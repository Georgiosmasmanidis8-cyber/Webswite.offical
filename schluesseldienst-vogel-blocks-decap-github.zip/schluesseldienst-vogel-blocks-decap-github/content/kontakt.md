---
title: "Kontakt"
---

<div id="form-success" class="alert" style="display:none">Danke! Wir melden uns schnellstmöglich.</div>

**Telefon:** [{{< raw >}}{{< /raw >}}]({{< raw >}}tel:{{< /raw >}}{{< raw >}}{{< /raw >}})

**E-Mail:** [{{< raw >}}{{< /raw >}}]({{< raw >}}mailto:{{< /raw >}}{{< raw >}}{{< /raw >}})

**Adresse:** {{< raw >}}{{< /raw >}}

<form name="Kontakt" method="POST"  action="https://formspree.io/f/your_form_id">
  <p><label>Ihr Name<br><input type="text" name="name" required></label></p>
  <p><label>Telefon oder E-Mail<br><input type="text" name="contact" required></label></p>
  <p><label>Nachricht<br><textarea name="message" rows="5" required></textarea></label></p>
  <p><button class="btn" type="submit">Nachricht senden</button></p>
  <p class="small">Mit dem Absenden akzeptieren Sie unsere <a href="/datenschutz">Datenschutzerklärung</a>.</p>
</form>
